import React, { useState } from "react";
import axios from "axios";
import "./styles/style.css";


function App() {

  const [data, setData] = useState({
    invoice_number: "",
    client_name: "",
    client_email: "",
    project_name: "",
    amount: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    axios({
      method: "post",
      url: "http://localhost:8000/invoice/",
      data: data,
    })
      .then(function (res) {
        console.log(res.data)
      })
      .catch(function (error) {
        setFormResponse(error.response.data)
      });
  };

  return (
    <div>
      <div className="container">
        <h1>Enter Details</h1>
        <form onSubmit={handleSubmit}>
          <input
            onChange={(e) =>
              setData({ ...data, invoice_number: e.target.value })
            }
            type="text"
            placeholder="enter your invoice number"
          />
          <input
            onChange={(e) => setData({ ...data, client_name: e.target.value })}
            type="text"
            placeholder="Client Name"
          />
          <input
            onChange={(e) => setData({ ...data, client_email: e.target.value })}
            type="email"
            placeholder="Client email ID"
          />
          <input
            onChange={(e) => setData({ ...data, project_name: e.target.value })}
            type=" text"
            placeholder="Project name"
          />
          <input
            onChange={(e) => setData({ ...data, amount: e.target.value })}
            type="number"
            placeholder="amount to be charged"
          />
          <button type="submit">Send</button>
        </form>
      </div>
    </div>
  );
}

export default App;
